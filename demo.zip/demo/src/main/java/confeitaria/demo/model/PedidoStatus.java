package confeitaria.demo.model;

public enum PedidoStatus {
    PENDENTE,
    EM_PRODUCAO,
    PRONTO,
    ENTREGUE
}

